#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// #include <pcre.h>

using namespace std;
#include <string>
//#include <sstream>
#include <vector>
//#include <set>
#include <map>
//#include <algorithm>

#include "xmlpd.h"
// #include "pcreux.h"
#include "ssplit2.h"

#ifdef WIN32
#define SLASH '\\'
#else
#define SLASH '/'
#endif

string onlypath( string fullpath )
{
vector <string> splut; string newpath;
int n = ssplit2( &splut, fullpath, SLASH );
for	( int i = 0; i < n-1; ++i )
	{
	if	( i )
		newpath += SLASH;
	newpath += splut[i];
	}
return newpath;
}


int load_xml( string fullpath, int level, int levelmax )
{
xmlobj * lexml = new xmlobj( fullpath.c_str(), NULL );
if	( !(lexml->is) )
	return 1;
if	( level >= levelmax )
	return 0;
int status;
// valeurs temporaires
xelem * elem; string s, name, pack, localpath;

printf("<ul>\n");
while	( ( status = lexml->step() ) )
	{
	elem = &lexml->stac.back();
	switch	( status )
		{
		case 1 :
		// printf("~~~> %s\n", elem->tag.c_str() );
		if	( elem->tag == string("module") )
			{
			// printf("<li>--- module %s ---</li>\n", fullpath.c_str() );
			}
		else if	( elem->tag == string("doc") )
			{
			}
		else if	( elem->tag == string("signal") )
			{
			}
		else if	( elem->tag == string("awt") )
			{
			}
		else if	( elem->tag == string("page_start") )
			{
			}
		else if	( elem->tag == string("page_end") )
			{
			}
		else if	( elem->tag == string("Panel") )
			{
			}
		else if	( elem->tag == string("center") )
			{
			}
		else if	( elem->tag == string("instance") )
			{
			}
		else if	( elem->tag == string("ListDisplay") )
			{
			}
		else if	( elem->tag == string("MemoryDisplay") )
			{
			}
		else if	( elem->tag == string("node") )
			{
			}
		else if	( elem->tag == string("BoutonsLoadSaveMem") )
			{
			}
		else if	( elem->tag == string("list") )
			{
			}
		else if	( elem->tag == string("line_start") )
			{
			}
		else if	( elem->tag == string("line_end") )
			{
			}
		else if	( elem->tag == string("onglet") )
			{
			}
		else if	( elem->tag == string("SystemDisplay") )
			{
			}
		else if	( elem->tag == string("ImageSVG") )
			{
			}
		else if	( elem->tag == string("ElementSVG") )
			{
			}
		else if	( elem->tag == string("ElementSVG_StdLogic") )
			{
			}
		else if	( elem->tag == string("item") )
			{
			}
		else if	( elem->tag == string("") )
			{
			}
		else if	( elem->tag == string("code") )
			{
			s = elem->attr[string("language")];		// copier son nom
			if	( s.size() )
				printf("<li><span class=\"code\">[code %s]</span></li>\n", s.c_str() );
			}
		else	{	// element non predefini
			vector <string> splut; string newpath;
			printf("<li>%s", elem->tag.c_str() );
			name = elem->attr[string("name")];		// copier son nom
			pack = elem->attr[string("package")];
			if	( pack.size() )
				printf(" {%s}", pack.c_str() );
			printf(" <span class=\"n\">%s</span>", name.c_str() );
			if	( pack.size() > 0 )			// pack est utlise comme prefixe
				newpath = pack + '.' + elem->tag;
			else	newpath = elem->tag;
								// on va commencer a chercher le module master
			int n = ssplit2( &splut, newpath, '.' );
			if	( ( n ) && ( splut[0] != string("lilas") ) )
				{
				if	( n == 1 )			// local ?
					{
					localpath = onlypath( fullpath );
					newpath = localpath + SLASH + splut[0];
					}
				else	{				// global
					newpath = "";
					for	( int i = 0; i < n; ++i )
						{
						if	( i )
							newpath += SLASH;
						newpath += splut[i];
						}
					}
				newpath += string(".lilas");
				printf(" <b>%s</b>",  newpath.c_str() );
				n = load_xml( newpath, level+1, levelmax );
				if	( n )
					printf("<span class=\"err\">Err %d</span>", n );
				}
			printf("</li>\n");
			}
		break;
		case 2 :
		break;
		default :
		printf("%s ligne %d : syntaxe xml %d\n", lexml->filepath, (lexml->curlin+1), status );
		printf("</ul>\n"); return -2;
		}
	}	// while status
printf("</ul>\n");
return 0;
}

int main( int argc, char *argv[] )
{
int retval, level_max;
if	( argc >= 3 )
	{
	level_max = atoi( argv[2] );
	printf("<html><head><style type=\"text/css\">\n");
	printf("span.n { background-color:#BF8; }\n");
	printf("span.code { background-color:#FC8; }\n");
	printf("span.err { background-color:#F77; }\n");
	printf("</style></head><body>\n");
	printf("<h2>%s</h2>\n", argv[1] );
	retval = load_xml( string( argv[1] ), 0, level_max );
	if	( retval )
		{
		printf("problem avec %s\n", argv[1] );
		return retval;
		}
	}
return 0;
}
